<?php
define("DB_HOST", "localhost");
define("DB_USER", "amarvote_2018");
define("DB_PASS", "2w3e4r5t6y7u8i");
define("DB_NAME", "amarvote_2018");
define('TITLE', 'Amar.Vote');
define('KEYWORDS', 'Bangladesh, elections, 2018, amar, vote');



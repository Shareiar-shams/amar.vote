<div class="grid_2">
<div class="box sidemenu">
<div class="block" id="section-menu">
<ul class="section menu">
<li><a class="menuitem">Participate Option</a>
    <ul class="submenu">
        <!--<li><a href="addParticipate.php">Add Participate</a> </li>-->
        <li><a href="allParticipate.php">Participate List</a> </li>
    </ul>
</li>
<!--<li><a class="menuitem">Participate User Info</a>-->
<!--    <ul class="submenu">-->
<!--        <li><a href="addParticipate.php">Add Participate User</a> </li>-->
<!--        <li><a href="allParticipate.php">User Participate List</a> </li>-->
<!--    </ul>-->
<!--</li>-->
<!--<li><a class="menuitem">Participate Vote Count</a>-->
<!--    <ul class="submenu">-->
<!--        <li><a href="allParticipate.php">All Participate Voter & Vote List</a> </li>-->
<!--    </ul>-->
<!--</li>-->
</ul>
</div>
</div>
</div>